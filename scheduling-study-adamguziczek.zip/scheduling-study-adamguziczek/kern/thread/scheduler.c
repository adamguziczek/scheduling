/*
 * Copyright (c) 2000, 2001, 2002, 2003, 2004, 2005, 2008, 2009
 *	The President and Fellows of Harvard College.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. Neither the name of the University nor the names of its contributors
 *    may be used to endorse or promote products derived from this software
 *    without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE UNIVERSITY AND CONTRIBUTORS ``AS IS'' AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE UNIVERSITY OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */

#include <types.h>
#include <lib.h>
#include <thread.h>
#include <threadlist.h>
#include <cpu.h>
#include <spl.h>
#include <current.h>
#include <scheduler.h>

/* Current scheduler type */
scheduler_type_t current_scheduler = SCHED_MLFQ; /* Default to MLFQ */

/* Priority queues for MLFQ scheduler */
struct threadlist mlfq_queues[MLFQ_LEVELS];
struct spinlock mlfq_lock;

/* Hardclock counter for priority boost */
unsigned mlfq_boost_counter = 0;

/*
 * Initialize the scheduler.
 */
void
scheduler_bootstrap(void)
{
    int i;

    /* Initialize MLFQ queues */
    for (i = 0; i < MLFQ_LEVELS; i++) {
        threadlist_init(&mlfq_queues[i]);
    }

    /* Initialize MLFQ lock */
    spinlock_init(&mlfq_lock);

    /* Initialize boost counter */
    mlfq_boost_counter = 0;
}

/*
 * Get the next thread to run based on the current scheduler.
 */
struct thread *
scheduler_getnext(struct threadlist *runqueue)
{
    struct thread *t = NULL;
    int i;

    switch (current_scheduler) {
        case SCHED_FCFS:
            /* FCFS: Just get the first thread in the run queue */
            t = threadlist_remhead(runqueue);
            break;

        case SCHED_MLFQ:
            /* MLFQ: Get the first thread from the highest priority non-empty queue */
            spinlock_acquire(&mlfq_lock);
            for (i = 0; i < MLFQ_LEVELS; i++) {
                t = threadlist_remhead(&mlfq_queues[i]);
                if (t != NULL) {
                    break;
                }
            }
            spinlock_release(&mlfq_lock);
            break;
    }

    return t;
}

/*
 * Update thread priority based on its CPU usage.
 */
void
scheduler_update_priority(struct thread *t)
{
    if (current_scheduler != SCHED_MLFQ) {
        return;
    }

    /* If thread has used its time slice, demote it to a lower priority */
    if (t->t_cpu_time >= t->t_time_slice) {
        if (t->t_priority < MLFQ_LEVELS - 1) {
            t->t_priority++;
        }
        t->t_cpu_time = 0;
        t->t_time_slice = MLFQ_TIME_SLICE * (t->t_priority + 1);
    }
}

/*
 * Perform a priority boost (move all threads to highest priority queue).
 */
void
scheduler_priority_boost(void)
{
    struct thread *t;
    int i;

    if (current_scheduler != SCHED_MLFQ) {
        return;
    }

    spinlock_acquire(&mlfq_lock);

    /* Move all threads to the highest priority queue */
    for (i = 1; i < MLFQ_LEVELS; i++) {
        while (!threadlist_isempty(&mlfq_queues[i])) {
            t = threadlist_remhead(&mlfq_queues[i]);
            if (t != NULL) {
                t->t_priority = MLFQ_DEFAULT_PRIORITY;
                t->t_cpu_time = 0;
                t->t_time_slice = MLFQ_TIME_SLICE;
                threadlist_addtail(&mlfq_queues[MLFQ_DEFAULT_PRIORITY], t);
            }
        }
    }

    /* Reset boost counter */
    mlfq_boost_counter = 0;

    spinlock_release(&mlfq_lock);
}

/*
 * Add a thread to the appropriate run queue based on the current scheduler.
 */
void
scheduler_addthread(struct thread *t, struct threadlist *runqueue)
{
    switch (current_scheduler) {
        case SCHED_FCFS:
            /* FCFS: Add to the end of the run queue */
            threadlist_addtail(runqueue, t);
            break;

        case SCHED_MLFQ:
            /* MLFQ: Add to the appropriate priority queue */
            spinlock_acquire(&mlfq_lock);
            threadlist_addtail(&mlfq_queues[t->t_priority], t);
            spinlock_release(&mlfq_lock);
            break;
    }
}